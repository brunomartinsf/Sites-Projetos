
package utilitarios;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;


public class ConectaBanco {
   public Statement stm;
   public ResultSet rs;
   private String driver="com.mysql.jdbc.Driver";
   private String caminho="jdbc:mysql://localhost/graficabd";
   private String usuario="root";
   private String senha="123456";
   public Connection conn=null;
   
   
   public void conexao(){
       try {
            System.setProperty("jdbc.Drivers",driver);
            conn=DriverManager.getConnection(caminho, usuario, senha);
           //JOptionPane.showMessageDialog(null, "Conectado com sucesso");     
       } catch (SQLException ex) {
           JOptionPane.showMessageDialog(null, "Erro na conexão!");
       }
   }
  
   public static Connection ConnecrDb(){
   
       try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn=DriverManager.getConnection("jdbc:mysql://localhost/graficabd","root","123456");
           //JOptionPane.showMessageDialog(null, "Conectado com sucesso");     
           return conn;
       } catch (Exception e) {
           JOptionPane.showMessageDialog(null, "Erro na conexão!"+ e);
           return null;
       }
   }
   
   
   public void executaSQL(String sql){
       try {
           stm=conn.createStatement(rs.TYPE_SCROLL_INSENSITIVE,rs.CONCUR_READ_ONLY);
           rs=stm.executeQuery(sql);
       } catch (SQLException ex) {
           JOptionPane.showMessageDialog(null, "Erro de executa SQL!");
       }
   }
   
   public void desconecta(){
       try {
           conn.close();
       } catch (SQLException ex) {
           JOptionPane.showMessageDialog(null, "Erro ao desconectar");
       }
   }
}
