
package sistemagrafica;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import utilitarios.ConectaBanco;

public class Editarfuncionarios extends javax.swing.JFrame {
ConectaBanco conecta = new ConectaBanco();
   

    public Editarfuncionarios() {
        initComponents();
        conecta.conexao();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        campoideditar = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        camponomeedicao = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        campomanhaentrada = new javax.swing.JTextField();
        try{
            javax.swing.text.MaskFormatter entradamanhapedit= new javax.swing.text.MaskFormatter("##:##");
            campomanhaentrada = new javax.swing.JFormattedTextField(entradamanhapedit);
        }
        catch (Exception e){
        }
        jLabel6 = new javax.swing.JLabel();
        campomanhasaida = new javax.swing.JTextField();
        try{
            javax.swing.text.MaskFormatter saidamanhapedit= new javax.swing.text.MaskFormatter("##:##");
            campomanhasaida = new javax.swing.JFormattedTextField(saidamanhapedit);
        }
        catch (Exception e){
        }
        jLabel7 = new javax.swing.JLabel();
        campotardeentrada = new javax.swing.JTextField();
        try{
            javax.swing.text.MaskFormatter entradatardepedit= new javax.swing.text.MaskFormatter("##:##");
            campotardeentrada = new javax.swing.JFormattedTextField(entradatardepedit);
        }
        catch (Exception e){
        }
        jLabel8 = new javax.swing.JLabel();
        campotardesaida = new javax.swing.JTextField();
        try{
            javax.swing.text.MaskFormatter saidatardepedit= new javax.swing.text.MaskFormatter("##:##");
            campotardesaida = new javax.swing.JFormattedTextField(saidatardepedit);
        }
        catch (Exception e){
        }
        btnprimeiro = new javax.swing.JButton();
        btnultimo = new javax.swing.JButton();
        btnsalvaredicao = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        btnanterior = new javax.swing.JButton();
        btnproximo = new javax.swing.JButton();

        jLabel1.setText("jLabel1");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setText("Editar Funcionarios");

        jLabel3.setText("ID:");

        campoideditar.setEnabled(false);

        jLabel4.setText("Nome:");

        jLabel5.setText("Entrada manhã (padrão):");

        jLabel6.setText("Saida manhã (padrão):");

        jLabel7.setText("Entrada tarde (padrão):");

        jLabel8.setText("Saida tarde (padrão):");

        btnprimeiro.setText("<<");
        btnprimeiro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnprimeiroActionPerformed(evt);
            }
        });

        btnultimo.setText(">>");
        btnultimo.setEnabled(false);
        btnultimo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnultimoActionPerformed(evt);
            }
        });

        btnsalvaredicao.setText("Editar");
        btnsalvaredicao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsalvaredicaoActionPerformed(evt);
            }
        });

        btnanterior.setText("<");
        btnanterior.setEnabled(false);
        btnanterior.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnanteriorActionPerformed(evt);
            }
        });

        btnproximo.setText(">");
        btnproximo.setEnabled(false);
        btnproximo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnproximoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(170, 170, 170))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(camponomeedicao))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnprimeiro)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnanterior)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnproximo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnultimo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnsalvaredicao))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(campoideditar, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel5)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(campomanhaentrada))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel7)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(campotardeentrada, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(87, 87, 87)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(jLabel6)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel8)
                                        .addGap(10, 10, 10)))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(campotardesaida, javax.swing.GroupLayout.DEFAULT_SIZE, 51, Short.MAX_VALUE)
                                    .addComponent(campomanhasaida))))
                        .addGap(0, 26, Short.MAX_VALUE))
                    .addComponent(jSeparator1, javax.swing.GroupLayout.Alignment.TRAILING))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(campoideditar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(camponomeedicao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(campomanhaentrada, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(campomanhasaida, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(campotardeentrada, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8)
                    .addComponent(campotardesaida, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnprimeiro)
                    .addComponent(btnsalvaredicao)
                    .addComponent(btnanterior)
                    .addComponent(btnproximo)
                    .addComponent(btnultimo))
                .addContainerGap(52, Short.MAX_VALUE))
        );

        setSize(new java.awt.Dimension(491, 311));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnprimeiroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnprimeiroActionPerformed
        // TODO add your handling code here:
        btnanterior.setEnabled(true);
        btnproximo.setEnabled(true);
        btnultimo.setEnabled(true);
            
    try {
        conecta.executaSQL("select * from funcionarios");
        conecta.rs.first();
        campoideditar.setText(String.valueOf(conecta.rs.getInt("id")));
        camponomeedicao.setText(conecta.rs.getString("nomefuncionarios"));
        campomanhaentrada.setText(conecta.rs.getString("entradamanhapadrao"));
        campomanhasaida.setText(conecta.rs.getString("saidamanhapadrao"));
        campotardeentrada.setText(conecta.rs.getString("entradatardepadrao"));
        campotardesaida.setText(conecta.rs.getString("saidatardepadrao"));
        
    } catch (SQLException ex) {
      // JOptionPane.showMessageDialog(null, "Erro ao mostrar dados!");
    }
   
    }//GEN-LAST:event_btnprimeiroActionPerformed

    private void btnultimoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnultimoActionPerformed
        // TODO add your handling code here:
        try {
        conecta.executaSQL("select * from funcionarios");
        conecta.rs.last();
        campoideditar.setText(String.valueOf(conecta.rs.getInt("id")));
        camponomeedicao.setText(conecta.rs.getString("nomefuncionarios"));
        campomanhaentrada.setText(conecta.rs.getString("entradamanhapadrao"));
        campomanhasaida.setText(conecta.rs.getString("saidamanhapadrao"));
        campotardeentrada.setText(conecta.rs.getString("entradatardepadrao"));
        campotardesaida.setText(conecta.rs.getString("saidatardepadrao"));
    } catch (SQLException ex) {
      // JOptionPane.showMessageDialog(null, "Erro ao mostrar dados!");
    }
    }//GEN-LAST:event_btnultimoActionPerformed

    private void btnanteriorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnanteriorActionPerformed
    try {
        // TODO add your handling code here:
        conecta.rs.previous();
        campoideditar.setText(String.valueOf(conecta.rs.getInt("id")));
        camponomeedicao.setText(conecta.rs.getString("nomefuncionarios"));
        campomanhaentrada.setText(conecta.rs.getString("entradamanhapadrao"));
        campomanhasaida.setText(conecta.rs.getString("saidamanhapadrao"));
        campotardeentrada.setText(conecta.rs.getString("entradatardepadrao"));
        campotardesaida.setText(conecta.rs.getString("saidatardepadrao"));
    } catch (SQLException ex) {
       // JOptionPane.showMessageDialog(null, "Erro ao mostrar dados!");
    }
        
        
    }//GEN-LAST:event_btnanteriorActionPerformed

    private void btnproximoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnproximoActionPerformed
        // TODO add your handling code here:
        try {
        // TODO add your handling code here:
        conecta.rs.next();
        campoideditar.setText(String.valueOf(conecta.rs.getInt("id")));
        camponomeedicao.setText(conecta.rs.getString("nomefuncionarios"));
        campomanhaentrada.setText(conecta.rs.getString("entradamanhapadrao"));
        campomanhasaida.setText(conecta.rs.getString("saidamanhapadrao"));
        campotardeentrada.setText(conecta.rs.getString("entradatardepadrao"));
        campotardesaida.setText(conecta.rs.getString("saidatardepadrao"));
    } catch (SQLException ex) {
        //JOptionPane.showMessageDialog(null, "Erro ao mostrar dados!");
    }
    }//GEN-LAST:event_btnproximoActionPerformed

    private void btnsalvaredicaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsalvaredicaoActionPerformed
        // TODO add your handling code here:
        
        try {
            // TODO add your handling code here:
            PreparedStatement pst = conecta.conn.prepareStatement("update funcionarios set nomefuncionarios=?,entradamanhapadrao=?,saidamanhapadrao=?,entradatardepadrao=?,saidatardepadrao=? where id=?");
            pst.setString(1,camponomeedicao.getText());
            pst.setString(2,campomanhaentrada.getText());
            pst.setString(3,campomanhasaida.getText());
            pst.setString(4,campotardeentrada.getText());
            pst.setString(5,campotardesaida.getText());
            pst.setInt(6,Integer.parseInt(campoideditar.getText()));
            pst.execute();
            JOptionPane.showMessageDialog(rootPane, "Editado com sucesso!");
            campoideditar.setText("");
            camponomeedicao.setText("");
            campomanhaentrada.setText("");
            campomanhasaida.setText("");
            campotardeentrada.setText("");
            campotardesaida.setText("");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao Editar!"+ ex);
        }
    }//GEN-LAST:event_btnsalvaredicaoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Editarfuncionarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Editarfuncionarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Editarfuncionarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Editarfuncionarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Editarfuncionarios().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnanterior;
    private javax.swing.JButton btnprimeiro;
    private javax.swing.JButton btnproximo;
    private javax.swing.JButton btnsalvaredicao;
    private javax.swing.JButton btnultimo;
    private javax.swing.JTextField campoideditar;
    private javax.swing.JTextField campomanhaentrada;
    private javax.swing.JTextField campomanhasaida;
    private javax.swing.JTextField camponomeedicao;
    private javax.swing.JTextField campotardeentrada;
    private javax.swing.JTextField campotardesaida;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JSeparator jSeparator1;
    // End of variables declaration//GEN-END:variables
}
