package sistemagrafica;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import utilitarios.ConectaBanco;
import utilitarios.ModeloTabela;
import net.proteanit.sql.DbUtils;

public class Cadastroentradasaida extends javax.swing.JFrame {
    ConectaBanco conncadponto= new ConectaBanco();
    Connection conn =null;
    ResultSet rs = null;
    PreparedStatement pst = null;
    ConectaBanco conecta = new ConectaBanco();
    
    
    public Cadastroentradasaida() {
        initComponents();
        conn = ConectaBanco.ConnecrDb();
        conecta.conexao();
        preencherCombo();
        dataAtual();
        preencherTabela2("select * from cadentradasaida1 order by ID");
        
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jComboBoxnomefunc = new javax.swing.JComboBox<String>();
        jLabel2 = new javax.swing.JLabel();
        txtentradamanhapadrao = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtsaidamanhapadrao = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtentradatardepadrao = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtsaidatardepadrao = new javax.swing.JTextField();
        horamanhachegada = new javax.swing.JTextField();
        try{
            javax.swing.text.MaskFormatter horariomanhaentrada= new javax.swing.text.MaskFormatter("##:##");
            horamanhachegada = new javax.swing.JFormattedTextField(horariomanhaentrada);
        }
        catch (Exception e){
        }
        jLabel7 = new javax.swing.JLabel();
        manhasaida = new javax.swing.JTextField();
        try{
            javax.swing.text.MaskFormatter horariomanhasaida= new javax.swing.text.MaskFormatter("##:##");
            manhasaida = new javax.swing.JFormattedTextField(horariomanhasaida);
        }
        catch (Exception e){
        }
        jLabel8 = new javax.swing.JLabel();
        tardechegada = new javax.swing.JTextField();
        try{
            javax.swing.text.MaskFormatter horariotardeentrada= new javax.swing.text.MaskFormatter("##:##");
            tardechegada = new javax.swing.JFormattedTextField(horariotardeentrada);
        }
        catch (Exception e){
        }
        jLabel9 = new javax.swing.JLabel();
        tardesaida = new javax.swing.JTextField();
        try{
            javax.swing.text.MaskFormatter horariotardesaida= new javax.swing.text.MaskFormatter("##:##");
            tardesaida = new javax.swing.JFormattedTextField(horariotardesaida);
        }
        catch (Exception e){
        }
        btnsalvar = new javax.swing.JButton();
        btnfaltamanha = new javax.swing.JButton();
        btnfaltatarde = new javax.swing.JButton();
        btnlimpar = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        txtdataatual = new javax.swing.JTextField();
        jSeparator2 = new javax.swing.JSeparator();
        jScrollPane2 = new javax.swing.JScrollPane();
        Tabelaentradasaida = new javax.swing.JTable();
        jLabel11 = new javax.swing.JLabel();
        btncalcular1 = new javax.swing.JButton();
        resultado1 = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        resultado2 = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        resultado3 = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        resultado4 = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        btncalcular2 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        txtexclusao = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        btncalcular1_1 = new javax.swing.JButton();
        btncalcular2_2 = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        txtpesquisa = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        btneditarentradasaida = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Cadastro Entrada/Saida");
        setResizable(false);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel1.setText("Cadastro Entrada/Saida");

        jComboBoxnomefunc.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Funcionario:" }));
        jComboBoxnomefunc.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
                jComboBoxnomefuncPopupMenuWillBecomeInvisible(evt);
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
            }
        });
        jComboBoxnomefunc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jComboBoxnomefuncMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jComboBoxnomefuncMouseEntered(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jComboBoxnomefuncMouseReleased(evt);
            }
        });
        jComboBoxnomefunc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxnomefuncActionPerformed(evt);
            }
        });

        jLabel2.setText("Entrada manhã (Padrão):");

        txtentradamanhapadrao.setEditable(false);

        jLabel3.setText("Saida manhã (Padrão):");

        txtsaidamanhapadrao.setEditable(false);

        jLabel4.setText("Entrada tarde (Padrão):");

        txtentradatardepadrao.setEditable(false);
        txtentradatardepadrao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtentradatardepadraoActionPerformed(evt);
            }
        });

        jLabel5.setText("Saida tarde (Padrão):");

        txtsaidatardepadrao.setEditable(false);
        txtsaidatardepadrao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtsaidatardepadraoActionPerformed(evt);
            }
        });

        horamanhachegada.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                horamanhachegadaActionPerformed(evt);
            }
        });

        jLabel7.setText("Horário manhã saida:");

        jLabel8.setText("Horário tarde chegada:");

        jLabel9.setText("Horário tarde saida:");

        btnsalvar.setText("Salvar");
        btnsalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsalvarActionPerformed(evt);
            }
        });

        btnfaltamanha.setText("Falta manhã");
        btnfaltamanha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnfaltamanhaActionPerformed(evt);
            }
        });

        btnfaltatarde.setText("Falta tarde");
        btnfaltatarde.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnfaltatardeActionPerformed(evt);
            }
        });

        btnlimpar.setText("Limpar");
        btnlimpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnlimparActionPerformed(evt);
            }
        });

        jLabel10.setText("Data:");

        txtdataatual.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtdataatualActionPerformed(evt);
            }
        });

        Tabelaentradasaida.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane2.setViewportView(Tabelaentradasaida);

        jLabel11.setText("Obs. manha chegada:");

        btncalcular1.setText("Calcula manhã entrada");
        btncalcular1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btncalcular1ActionPerformed(evt);
            }
        });

        resultado1.setEnabled(false);

        jLabel12.setText("Obs. manhã saida:");

        resultado2.setEnabled(false);
        resultado2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resultado2ActionPerformed(evt);
            }
        });

        jLabel13.setText("Obs. tarde chegada:");

        resultado3.setEnabled(false);

        jLabel14.setText("Obs. tarde saida:");

        resultado4.setEnabled(false);

        jLabel15.setText("Horário manhã entrada:");

        btncalcular2.setText("Calcula tarde entrada");
        btncalcular2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btncalcular2ActionPerformed(evt);
            }
        });

        jButton1.setText("Excuir");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel6.setText("ID Exclusão:");

        btncalcular1_1.setText("Calcula manhã saida");
        btncalcular1_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btncalcular1_1ActionPerformed(evt);
            }
        });

        btncalcular2_2.setText("Calcula tarde saida");
        btncalcular2_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btncalcular2_2ActionPerformed(evt);
            }
        });

        jLabel16.setText("Pesquisar por data:");

        jButton2.setText("Buscar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        btneditarentradasaida.setText("Editar");
        btneditarentradasaida.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btneditarentradasaidaActionPerformed(evt);
            }
        });

        jButton3.setText("Atualizar");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(517, 517, 517)
                .addComponent(jLabel1)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jSeparator1)
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jComboBoxnomefunc, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnfaltatarde, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel2)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(txtentradamanhapadrao, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(74, 74, 74)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jLabel3)
                                                .addGap(18, 18, 18)
                                                .addComponent(txtsaidamanhapadrao, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jLabel7)
                                                .addGap(26, 26, 26)
                                                .addComponent(manhasaida, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel9)
                                            .addComponent(jLabel5)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(33, 33, 33)
                                                .addComponent(jLabel11)
                                                .addGap(93, 93, 93)
                                                .addComponent(jLabel12))
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(13, 13, 13)
                                                .addComponent(btncalcular1)))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel10)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtdataatual, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(jLabel15)
                                .addGap(18, 18, 18)
                                .addComponent(horamanhachegada, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tardesaida, javax.swing.GroupLayout.DEFAULT_SIZE, 75, Short.MAX_VALUE)
                            .addComponent(txtsaidatardepadrao))
                        .addGap(19, 19, 19))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jSeparator2)
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnfaltamanha)
                        .addGap(63, 63, 63)
                        .addComponent(resultado1, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(59, 59, 59)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btncalcular1_1)
                            .addComponent(resultado2, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(154, 154, 154)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(67, 67, 67)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLabel8)
                                            .addGap(30, 30, 30)
                                            .addComponent(tardechegada, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLabel4)
                                            .addGap(30, 30, 30)
                                            .addComponent(txtentradatardepadrao, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(146, 146, 146)
                                        .addComponent(jLabel14)))
                                .addContainerGap())
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(12, 12, 12)
                                        .addComponent(resultado3, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(7, 7, 7)
                                        .addComponent(btncalcular2))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(28, 28, 28)
                                        .addComponent(jLabel13)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 54, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(resultado4, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(207, 207, 207))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(btncalcular2_2)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(btnsalvar)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnlimpar)
                                        .addContainerGap())))))))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel16)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtpesquisa, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton2)
                        .addGap(287, 287, 287)
                        .addComponent(jButton3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtexclusao, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btneditarentradasaida)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtentradatardepadrao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tardechegada, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel14))
                        .addGap(141, 141, 141))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jComboBoxnomefunc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2)
                            .addComponent(txtentradamanhapadrao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3)
                            .addComponent(txtsaidamanhapadrao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5)
                            .addComponent(txtsaidatardepadrao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(manhasaida, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(horamanhachegada, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel9)
                                .addComponent(tardesaida, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel10)
                                .addComponent(jLabel15)
                                .addComponent(jLabel7)
                                .addComponent(txtdataatual, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel12)
                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(15, 15, 15)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(resultado4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(resultado1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(resultado2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(resultado3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btncalcular2)
                                    .addComponent(btncalcular2_2)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(btnsalvar)
                                        .addComponent(btnlimpar))))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(btnfaltamanha)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(btnfaltatarde)
                                    .addComponent(btncalcular1)
                                    .addComponent(btncalcular1_1))))
                        .addGap(18, 18, 18)
                        .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jButton1)
                                .addComponent(txtexclusao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel6))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel16)
                                .addComponent(txtpesquisa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButton2)
                                .addComponent(btneditarentradasaida)
                                .addComponent(jButton3)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(199, 199, 199))
        );

        setSize(new java.awt.Dimension(1233, 608));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtsaidatardepadraoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtsaidatardepadraoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtsaidatardepadraoActionPerformed

    private void btnfaltamanhaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnfaltamanhaActionPerformed
        // TODO add your handling code here:
        horamanhachegada.setText("");
        manhasaida.setText("");
        resultado1.setText("Falta");
        resultado2.setText("Falta");
        btncalcular1.setVisible(false);
        btncalcular1_1.setVisible(false);
       
        
    }//GEN-LAST:event_btnfaltamanhaActionPerformed

    private void btnfaltatardeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnfaltatardeActionPerformed
        // TODO add your handling code here:
        tardechegada.setText("");
        tardesaida.setText("");
        tardechegada.setText("Falta");
        tardesaida.setText("Falta");
        resultado3.setText("Falta");
        resultado4.setText("Falta");
        btncalcular2.setVisible(false);
        btncalcular2_2.setVisible(false);
    }//GEN-LAST:event_btnfaltatardeActionPerformed

    private void jComboBoxnomefuncActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxnomefuncActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_jComboBoxnomefuncActionPerformed

    private void jComboBoxnomefuncMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jComboBoxnomefuncMouseClicked
        // TODO add your handling code here:
           
    }//GEN-LAST:event_jComboBoxnomefuncMouseClicked

    private void jComboBoxnomefuncMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jComboBoxnomefuncMouseReleased
        // TODO add your handling code here:
        
    }//GEN-LAST:event_jComboBoxnomefuncMouseReleased

    private void jComboBoxnomefuncMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jComboBoxnomefuncMouseEntered
        // TODO add your handling code here:
      
    }//GEN-LAST:event_jComboBoxnomefuncMouseEntered

    private void jComboBoxnomefuncPopupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_jComboBoxnomefuncPopupMenuWillBecomeInvisible
        // TODO add your handling code here:
        String tmp = (String)jComboBoxnomefunc.getSelectedItem();
        String sql = "select * from funcionarios where nomefuncionarios=?";     
        try {
            pst=conn.prepareStatement(sql);
            pst.setString(1, tmp);
            rs=pst.executeQuery();
            if(rs.next()){
                String add1 = rs.getString("entradamanhapadrao");
                txtentradamanhapadrao.setText(add1);
                String add2 = rs.getString("saidamanhapadrao");
                txtsaidamanhapadrao.setText(add2);
                String add3 = rs.getString("entradatardepadrao");
                txtentradatardepadrao.setText(add3);
                String add4 = rs.getString("saidatardepadrao");
                txtsaidatardepadrao.setText(add4);
            }
        } catch (SQLException ex) {
            
            Logger.getLogger(Cadastroentradasaida.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jComboBoxnomefuncPopupMenuWillBecomeInvisible

    private void txtdataatualActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtdataatualActionPerformed
        // TODO add your handling code here:        
        
    }//GEN-LAST:event_txtdataatualActionPerformed

    private void btnlimparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnlimparActionPerformed
        // TODO add your handling code here:
        resultado1.setText("");
        resultado2.setText("");
        resultado3.setText("");
        resultado4.setText("");     
        btncalcular1.setVisible(true);
        btncalcular1_1.setVisible(true);
        btncalcular2.setVisible(true);
        btncalcular2_2.setVisible(true);
        jComboBoxnomefunc.setSelectedIndex(0);
        txtentradamanhapadrao.setText("");
        txtsaidamanhapadrao.setText("");
        txtentradatardepadrao.setText("");
        txtsaidatardepadrao.setText("");
        horamanhachegada.setText("");
        manhasaida.setText("");
        tardechegada.setText("");
        tardesaida.setText("");
    }//GEN-LAST:event_btnlimparActionPerformed

    private void btncalcular1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncalcular1ActionPerformed
        // TODO add your handling code here:
        
        String v1= txtentradamanhapadrao.getText();
        String v2= horamanhachegada.getText();
       
      
         try {
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
        Calendar calInicial1 = Calendar.getInstance();
        Calendar calFinal1 = Calendar.getInstance();
        

        calInicial1.setTime(sdf.parse(v1));
        calFinal1.setTime(sdf.parse(v2));
        
         

        long minutos1 = ((calFinal1.getTimeInMillis() - calInicial1.getTimeInMillis())) / 60000;
        long resto1 = minutos1 % 60;
        long horas1 = minutos1 / 60;
        
        
        
        
        if(minutos1>0){
            resultado1.setText(Integer.toString((int) minutos1)+" Min. Atrasado");
            
        }
        if(minutos1<0){
            
            resultado1.setText(Integer.toString((int) minutos1 *(-1))+" Min. Adiantado");
            
        }
        
       if(minutos1==0){
            resultado1.setText(" Pontual");
       }
        
        
      
    } catch (ParseException e) {
        e.printStackTrace(); 
    }   
         
      
    }//GEN-LAST:event_btncalcular1ActionPerformed

    private void resultado2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resultado2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_resultado2ActionPerformed

    private void horamanhachegadaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_horamanhachegadaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_horamanhachegadaActionPerformed

    private void btncalcular2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncalcular2ActionPerformed
        // TODO add your handling code here:
        
         String v5 = txtentradatardepadrao.getText();
        String v6 = tardechegada.getText();
        
        
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
             Calendar calInicial3 = Calendar.getInstance();
            Calendar calFinal3 = Calendar.getInstance();
            


             calInicial3.setTime(sdf.parse(v5));
            calFinal3.setTime(sdf.parse(v6));
            

             long minutos3 = ((calFinal3.getTimeInMillis() - calInicial3.getTimeInMillis())) / 60000;
            long resto3 = minutos3 % 60;
            long horas3 = minutos3 / 60;

            

            if(minutos3>0){
                resultado3.setText(Integer.toString((int) minutos3)+" Min. Atrasado");

            }
            if(minutos3<0){

                resultado3.setText(Integer.toString((int) minutos3 *(-1))+" Min. Adiantado");

            }
            
            if(minutos3==0){
                resultado3.setText(" Pontual");
            }

            
        } catch (ParseException e) {
        e.printStackTrace(); 
    }   
    }//GEN-LAST:event_btncalcular2ActionPerformed

    private void btnsalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsalvarActionPerformed
        // TODO add your handling code here:
        try {
            // TODO add your handling code here:
            PreparedStatement pst = conecta.conn.prepareStatement("insert into cadentradasaida1(Nome,Data,EntradaManhãPadrão,HoraManhãEntrada,Obs_ManhãChegada,SaidaManhãPadrão,HoraManhãSaida,Obs_ManhãSaida,EntradaTardePadrão,HoraTardeEntrada,Obs_TardeChegada,SaidaTardePadrão,HoraTardeSaida,Obs_TardeSaida)values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            pst.setString(1,jComboBoxnomefunc.getSelectedItem().toString());
            pst.setString(2,txtdataatual.getText());
            pst.setString(3,txtentradamanhapadrao.getText());
            pst.setString(4,horamanhachegada.getText());
            pst.setString(5,resultado1.getText());
            pst.setString(6,txtsaidamanhapadrao.getText());
            pst.setString(7,manhasaida.getText());
            pst.setString(8,resultado2.getText());
            pst.setString(9,txtentradatardepadrao.getText());
            pst.setString(10,tardechegada.getText());
            pst.setString(11,resultado3.getText());
            pst.setString(12,txtsaidatardepadrao.getText());
            pst.setString(13,tardesaida.getText());
            pst.setString(14,resultado4.getText());
            pst.executeUpdate();
            JOptionPane.showMessageDialog(rootPane,"Salvo com sucesso!");
            jComboBoxnomefunc.setSelectedIndex(0);
            txtentradamanhapadrao.setText("");
            txtsaidamanhapadrao.setText("");
            txtentradatardepadrao.setText("");
            txtsaidatardepadrao.setText("");
            txtdataatual.setText("");
            horamanhachegada.setText("");
            manhasaida.setText("");
            tardechegada.setText("");
            tardesaida.setText("");
            resultado1.setText("");
            resultado2.setText("");
            resultado3.setText("");
            resultado4.setText("");
            btncalcular1.setVisible(true);
            btncalcular2.setVisible(true);
            preencherTabela2("select * from cadentradasaida1 order by ID");
            dataAtual();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane,"Erro na inserção!" + ex);
        }
    }//GEN-LAST:event_btnsalvarActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        try {
            // TODO add your handling code here:
            PreparedStatement pst = conecta.conn.prepareStatement("delete from cadentradasaida1 where ID=?");
            pst.setString(1,txtexclusao.getText());
            pst.execute();
            JOptionPane.showMessageDialog(null, "Excluido com sucesso!");
            txtexclusao.setText("");
            preencherTabela2("select * from cadentradasaida1 order by ID");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao Excluir!");
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void txtentradatardepadraoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtentradatardepadraoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtentradatardepadraoActionPerformed

    private void btncalcular1_1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncalcular1_1ActionPerformed
        // TODO add your handling code here:
         String v3 = txtsaidamanhapadrao.getText();
        String v4 = manhasaida.getText();
        
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
            Calendar calInicial2 = Calendar.getInstance();
             Calendar calFinal2 = Calendar.getInstance();
             
            calInicial2.setTime(sdf.parse(v3));
             calFinal2.setTime(sdf.parse(v4));
             
             long minutos2 = ((calFinal2.getTimeInMillis() - calInicial2.getTimeInMillis())) / 60000;
             long resto2 = minutos2 % 60;
             long horas2 = minutos2 / 60;
             
             
             
             if(minutos2>0){
            resultado2.setText(Integer.toString((int) minutos2)+" Min. Depois");
            
        }
        
        if(minutos2<0){
            resultado2.setText(Integer.toString((int) minutos2 *(-1))+" Min. Antes");
        }
        
        if(minutos2==0){
            resultado2.setText(" Pontual");
       }
             
        } catch (ParseException ex) {
            Logger.getLogger(Cadastroentradasaida.class.getName()).log(Level.SEVERE, null, ex);
        }
       
    }//GEN-LAST:event_btncalcular1_1ActionPerformed

    private void btncalcular2_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncalcular2_2ActionPerformed
        // TODO add your handling code here:
        String v7 = txtsaidatardepadrao.getText();
        String v8 = tardesaida.getText();
        
       
            
        try {
             SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
        Calendar calInicial4 = Calendar.getInstance();
            Calendar calFinal4 = Calendar.getInstance();
            calInicial4.setTime(sdf.parse(v7));
            
            calFinal4.setTime(sdf.parse(v8));
            
            long minutos4 = ((calFinal4.getTimeInMillis() - calInicial4.getTimeInMillis())) / 60000;
            long resto4 = minutos4 % 60;
            long horas4 = minutos4 / 60;
            
            if(minutos4>0){
                resultado4.setText(Integer.toString((int) minutos4)+" Min. Depois");

            }

            if(minutos4<0){
                resultado4.setText(Integer.toString((int) minutos4 *(-1))+" Min. Antes");
            }
        
            if(minutos4==0){
                resultado4.setText(" Pontual");
            } 
        } catch (ParseException ex) {
            Logger.getLogger(Cadastroentradasaida.class.getName()).log(Level.SEVERE, null, ex);
        }
            
    }//GEN-LAST:event_btncalcular2_2ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        pesquisar_entradasaida();
       
    }//GEN-LAST:event_jButton2ActionPerformed

    private void btneditarentradasaidaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btneditarentradasaidaActionPerformed
        // TODO add your handling code here:
        Editarentradasaida editar =  new  Editarentradasaida();
        editar.setVisible(true);
    }//GEN-LAST:event_btneditarentradasaidaActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        preencherTabela2("select * from cadentradasaida1 order by ID");
    }//GEN-LAST:event_jButton3ActionPerformed
    
    public void dataAtual(){
        Date data =  new Date();
        SimpleDateFormat formatar = new SimpleDateFormat("dd/MM/yyyy");
        String dataFormatada = formatar.format(data);
        txtdataatual.setText(dataFormatada);
    }
    
    public void preencherCombo(){
       try{
           String sql="select * from funcionarios";
           pst=conn.prepareStatement(sql);
           rs=pst.executeQuery();
           
           while(rs.next()){
           
               String name = rs.getString("nomefuncionarios");
               jComboBoxnomefunc.addItem(name);
           }
           
           
       }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);   
       }
    }
 
     private void pesquisar_entradasaida(){     
         
        String sql ="select * from cadentradasaida1 where Data like ?";
        
        try {
            pst = conn.prepareStatement(sql);
            pst.setString (1,"%"+txtpesquisa.getText()+"%");
            rs=pst.executeQuery();
            
            Tabelaentradasaida.setModel(DbUtils.resultSetToTableModel(rs));
            Tabelaentradasaida.getColumnModel().getColumn(0).setPreferredWidth(50);
        Tabelaentradasaida.getColumnModel().getColumn(0).setResizable(true);
        Tabelaentradasaida.getColumnModel().getColumn(1).setPreferredWidth(150);
        Tabelaentradasaida.getColumnModel().getColumn(1).setResizable(true);
        Tabelaentradasaida.getColumnModel().getColumn(2).setPreferredWidth(80);
        Tabelaentradasaida.getColumnModel().getColumn(2).setResizable(true);
        Tabelaentradasaida.getColumnModel().getColumn(3).setPreferredWidth(130);
        Tabelaentradasaida.getColumnModel().getColumn(3).setResizable(true);
        Tabelaentradasaida.getColumnModel().getColumn(4).setPreferredWidth(130);
        Tabelaentradasaida.getColumnModel().getColumn(4).setResizable(true);
        Tabelaentradasaida.getColumnModel().getColumn(5).setPreferredWidth(130);
        Tabelaentradasaida.getColumnModel().getColumn(5).setResizable(true);
        Tabelaentradasaida.getColumnModel().getColumn(6).setPreferredWidth(130);
        Tabelaentradasaida.getColumnModel().getColumn(6).setResizable(true);
        Tabelaentradasaida.getColumnModel().getColumn(7).setPreferredWidth(130);
        Tabelaentradasaida.getColumnModel().getColumn(7).setResizable(true);
        Tabelaentradasaida.getColumnModel().getColumn(8).setPreferredWidth(130);
        Tabelaentradasaida.getColumnModel().getColumn(8).setResizable(true);
        Tabelaentradasaida.getColumnModel().getColumn(9).setPreferredWidth(130);
        Tabelaentradasaida.getColumnModel().getColumn(9).setResizable(true);
        Tabelaentradasaida.getColumnModel().getColumn(10).setPreferredWidth(130);
        Tabelaentradasaida.getColumnModel().getColumn(10).setResizable(true);
        Tabelaentradasaida.getColumnModel().getColumn(11).setPreferredWidth(130);
        Tabelaentradasaida.getColumnModel().getColumn(11).setResizable(true);
        Tabelaentradasaida.getColumnModel().getColumn(12).setPreferredWidth(130);
        Tabelaentradasaida.getColumnModel().getColumn(12).setResizable(true);
        Tabelaentradasaida.getColumnModel().getColumn(13).setPreferredWidth(130);
        Tabelaentradasaida.getColumnModel().getColumn(13).setResizable(true);
        Tabelaentradasaida.getColumnModel().getColumn(14).setPreferredWidth(130);
        Tabelaentradasaida.getColumnModel().getColumn(14).setResizable(true);
        Tabelaentradasaida.setAutoResizeMode(Tabelaentradasaida.AUTO_RESIZE_OFF);
        Tabelaentradasaida.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            
        } catch (SQLException ex) {
            Logger.getLogger(Cadastroentradasaida.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
  public void preencherTabela2(String SQL){
        ArrayList dados = new ArrayList();
        String [] Colunas = new String[]{"ID","Nome","Data","Entrada manhã padrão","Hora manhã entrada","Obs. manhã chegada","Saida manhã padrão","Hora manhã saida","Obs. manhã saida","Entrada tarde padrão","Hora tarde entrada","Obs. tarde chegada","Saida tarde padrão","Hora tarde saida","Obs. tarde saida"};   
        conecta.executaSQL(SQL);
        try {
            conecta.rs.first();
            do{
                dados.add(new Object[]{conecta.rs.getInt("ID"),conecta.rs.getString("Nome"),conecta.rs.getString("Data"),conecta.rs.getString("EntradaManhãPadrão"),conecta.rs.getString("HoraManhãEntrada"),conecta.rs.getString("Obs_ManhãChegada"),conecta.rs.getString("SaidaManhãPadrão"),conecta.rs.getString("HoraManhãSaida"),conecta.rs.getString("Obs_ManhãSaida"),conecta.rs.getString("EntradaTardePadrão"),conecta.rs.getString("HoraTardeEntrada"),conecta.rs.getString("Obs_TardeChegada"),conecta.rs.getString("SaidaTardePadrão"),conecta.rs.getString("HoraTardeSaida"),conecta.rs.getString("Obs_TardeSaida")});
            }while(conecta.rs.next());
     } catch (SQLException ex) {
           //JOptionPane.showMessageDialog(null, "Erro ao preencher o ArrayList!");
        }
        
        ModeloTabela modelo = new ModeloTabela(dados, Colunas);
        Tabelaentradasaida.setModel(modelo);
        Tabelaentradasaida.getColumnModel().getColumn(0).setPreferredWidth(50);
        Tabelaentradasaida.getColumnModel().getColumn(0).setResizable(true);
        Tabelaentradasaida.getColumnModel().getColumn(1).setPreferredWidth(150);
        Tabelaentradasaida.getColumnModel().getColumn(1).setResizable(true);
        Tabelaentradasaida.getColumnModel().getColumn(2).setPreferredWidth(80);
        Tabelaentradasaida.getColumnModel().getColumn(2).setResizable(true);
        Tabelaentradasaida.getColumnModel().getColumn(3).setPreferredWidth(140);
        Tabelaentradasaida.getColumnModel().getColumn(3).setResizable(true);
        Tabelaentradasaida.getColumnModel().getColumn(4).setPreferredWidth(130);
        Tabelaentradasaida.getColumnModel().getColumn(4).setResizable(true);
        Tabelaentradasaida.getColumnModel().getColumn(5).setPreferredWidth(130);
        Tabelaentradasaida.getColumnModel().getColumn(5).setResizable(true);
        Tabelaentradasaida.getColumnModel().getColumn(6).setPreferredWidth(130);
        Tabelaentradasaida.getColumnModel().getColumn(6).setResizable(true);
        Tabelaentradasaida.getColumnModel().getColumn(7).setPreferredWidth(130);
        Tabelaentradasaida.getColumnModel().getColumn(7).setResizable(true);
        Tabelaentradasaida.getColumnModel().getColumn(8).setPreferredWidth(130);
        Tabelaentradasaida.getColumnModel().getColumn(8).setResizable(true);
        Tabelaentradasaida.getColumnModel().getColumn(9).setPreferredWidth(130);
        Tabelaentradasaida.getColumnModel().getColumn(9).setResizable(true);
        Tabelaentradasaida.getColumnModel().getColumn(10).setPreferredWidth(130);
        Tabelaentradasaida.getColumnModel().getColumn(10).setResizable(true);
        Tabelaentradasaida.getColumnModel().getColumn(11).setPreferredWidth(130);
        Tabelaentradasaida.getColumnModel().getColumn(11).setResizable(true);
        Tabelaentradasaida.getColumnModel().getColumn(12).setPreferredWidth(130);
        Tabelaentradasaida.getColumnModel().getColumn(12).setResizable(true);
        Tabelaentradasaida.getColumnModel().getColumn(13).setPreferredWidth(130);
        Tabelaentradasaida.getColumnModel().getColumn(13).setResizable(true);
        Tabelaentradasaida.getColumnModel().getColumn(14).setPreferredWidth(130);
        Tabelaentradasaida.getColumnModel().getColumn(14).setResizable(true);
        Tabelaentradasaida.setAutoResizeMode(Tabelaentradasaida.AUTO_RESIZE_OFF);
        Tabelaentradasaida.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    
    }
    
   
  

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Cadastroentradasaida.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Cadastroentradasaida.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Cadastroentradasaida.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Cadastroentradasaida.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Cadastroentradasaida().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable Tabelaentradasaida;
    private javax.swing.JButton btncalcular1;
    private javax.swing.JButton btncalcular1_1;
    private javax.swing.JButton btncalcular2;
    private javax.swing.JButton btncalcular2_2;
    private javax.swing.JButton btneditarentradasaida;
    private javax.swing.JButton btnfaltamanha;
    private javax.swing.JButton btnfaltatarde;
    private javax.swing.JButton btnlimpar;
    private javax.swing.JButton btnsalvar;
    private javax.swing.JTextField horamanhachegada;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JComboBox<String> jComboBoxnomefunc;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JTextField manhasaida;
    private javax.swing.JTextField resultado1;
    private javax.swing.JTextField resultado2;
    private javax.swing.JTextField resultado3;
    private javax.swing.JTextField resultado4;
    private javax.swing.JTextField tardechegada;
    private javax.swing.JTextField tardesaida;
    private javax.swing.JTextField txtdataatual;
    private javax.swing.JTextField txtentradamanhapadrao;
    private javax.swing.JTextField txtentradatardepadrao;
    private javax.swing.JTextField txtexclusao;
    private javax.swing.JTextField txtpesquisa;
    private javax.swing.JTextField txtsaidamanhapadrao;
    private javax.swing.JTextField txtsaidatardepadrao;
    // End of variables declaration//GEN-END:variables
}
