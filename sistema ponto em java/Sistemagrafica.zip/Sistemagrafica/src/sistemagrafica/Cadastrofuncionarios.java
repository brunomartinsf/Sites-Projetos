package sistemagrafica;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import utilitarios.ConectaBanco;
import utilitarios.ModeloTabela;


public class Cadastrofuncionarios extends javax.swing.JFrame {
    ConectaBanco conecta = new ConectaBanco();
    
    public Cadastrofuncionarios() {
        initComponents();
       conecta.conexao();
       preencherTabela("select * from funcionarios order by id");
        
    }  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel2 = new javax.swing.JLabel();
        camponome = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        campoentradamanha = new javax.swing.JTextField();
        try{
            javax.swing.text.MaskFormatter entradamanhap= new javax.swing.text.MaskFormatter("##:##");
            campoentradamanha = new javax.swing.JFormattedTextField(entradamanhap);
        }
        catch (Exception e){
        }
        jLabel4 = new javax.swing.JLabel();
        camposaidamanha = new javax.swing.JTextField();
        try{
            javax.swing.text.MaskFormatter saidamanhap= new javax.swing.text.MaskFormatter("##:##");
            camposaidamanha = new javax.swing.JFormattedTextField(saidamanhap);
        }
        catch (Exception e){
        }
        jLabel5 = new javax.swing.JLabel();
        campoentradatarde = new javax.swing.JTextField();
        try{
            javax.swing.text.MaskFormatter entradatardep= new javax.swing.text.MaskFormatter("##:##");
            campoentradatarde = new javax.swing.JFormattedTextField(entradatardep);
        }
        catch (Exception e){
        }
        jLabel6 = new javax.swing.JLabel();
        camposaidatarde = new javax.swing.JTextField();
        try{
            javax.swing.text.MaskFormatter saidatardep= new javax.swing.text.MaskFormatter("##:##");
            camposaidatarde = new javax.swing.JFormattedTextField(saidatardep);
        }
        catch (Exception e){
        }
        btnsalvar = new javax.swing.JButton();
        btnlimpar = new javax.swing.JButton();
        jSeparator2 = new javax.swing.JSeparator();
        jLabel8 = new javax.swing.JLabel();
        campoexclusao = new javax.swing.JTextField();
        btnexcluir = new javax.swing.JButton();
        btneditar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        Tabelafuncionarios = new javax.swing.JTable();
        btnatualizar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Cadastro Funcionarios");
        setResizable(false);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel1.setText("Cadastrar Funcionarios");

        jLabel2.setText("Nome completo:");

        jLabel3.setText("Entrada manhã (Padrão):");

        jLabel4.setText("Saida manhã (Padrão):");

        camposaidamanha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                camposaidamanhaActionPerformed(evt);
            }
        });

        jLabel5.setText("Entrada tarde (Padrão):");

        jLabel6.setText("Saida tarde (Padrão):");

        btnsalvar.setText("Salvar");
        btnsalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsalvarActionPerformed(evt);
            }
        });

        btnlimpar.setText("Limpar");
        btnlimpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnlimparActionPerformed(evt);
            }
        });

        jLabel8.setText("ID exclusão:");

        campoexclusao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                campoexclusaoActionPerformed(evt);
            }
        });

        btnexcluir.setText("Excluir");
        btnexcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnexcluirActionPerformed(evt);
            }
        });

        btneditar.setText("Editar");
        btneditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btneditarActionPerformed(evt);
            }
        });

        Tabelafuncionarios.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(Tabelafuncionarios);

        btnatualizar.setText("Atualizar");
        btnatualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnatualizarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addComponent(jSeparator2)
                    .addComponent(jSeparator1)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(camponome))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(campoentradamanha, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(camposaidamanha, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(campoentradatarde, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(camposaidatarde, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnsalvar)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 64, Short.MAX_VALUE)
                                .addComponent(btnlimpar))))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btneditar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnatualizar)
                        .addGap(272, 272, 272)
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(campoexclusao, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnexcluir)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(389, 389, 389))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(11, 11, 11)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(camponome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(campoentradamanha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(camposaidamanha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(campoentradatarde, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(camposaidatarde, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnsalvar)
                    .addComponent(btnlimpar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(campoexclusao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnexcluir)
                    .addComponent(btneditar)
                    .addComponent(btnatualizar))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        setSize(new java.awt.Dimension(991, 517));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void camposaidamanhaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_camposaidamanhaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_camposaidamanhaActionPerformed

    private void btnsalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsalvarActionPerformed
      try {
            // TODO add your handling code here:
            PreparedStatement pst = conecta.conn.prepareStatement("insert into funcionarios(nomefuncionarios,entradamanhapadrao,saidamanhapadrao,entradatardepadrao,saidatardepadrao)values(?,?,?,?,?)");
            pst.setString(1,camponome.getText());
            pst.setString(2,campoentradamanha.getText());
            pst.setString(3,camposaidamanha.getText());
            pst.setString(4,campoentradatarde.getText());
            pst.setString(5,camposaidatarde.getText());
            pst.executeUpdate();
            JOptionPane.showMessageDialog(rootPane,"Salvo com sucesso!");
            camponome.setText("");
            campoentradamanha.setText("");
            camposaidamanha.setText("");
            campoentradatarde.setText("");
            camposaidatarde.setText("");
            preencherTabela("select * from funcionarios order by id");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane,"Erro na inserção!");
        }
    }//GEN-LAST:event_btnsalvarActionPerformed

    private void btnlimparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnlimparActionPerformed
        // TODO add your handling code here:
        camponome.setText("");
        campoentradamanha.setText("");
        camposaidamanha.setText("");
        campoentradatarde.setText("");
        camposaidatarde.setText("");
    }//GEN-LAST:event_btnlimparActionPerformed

    private void campoexclusaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_campoexclusaoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_campoexclusaoActionPerformed

    private void btnexcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnexcluirActionPerformed
        try {
            // TODO add your handling code here:
            PreparedStatement pst = conecta.conn.prepareStatement("delete from funcionarios where id=?");
            pst.setString(1,campoexclusao.getText());
            pst.execute();
            JOptionPane.showMessageDialog(null, "Excluido com sucesso!");
            campoexclusao.setText("");
            preencherTabela("select * from funcionarios order by id");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao Excluir!");
        }
    }//GEN-LAST:event_btnexcluirActionPerformed

    private void btneditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btneditarActionPerformed
        // TODO add your handling code here:
        Editarfuncionarios editarfunc = new Editarfuncionarios();
        editarfunc.setVisible(true);
    }//GEN-LAST:event_btneditarActionPerformed

    private void btnatualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnatualizarActionPerformed
        // TODO add your handling code here:
        preencherTabela("select * from funcionarios order by id");
    }//GEN-LAST:event_btnatualizarActionPerformed
    public void preencherTabela(String SQL){
        ArrayList dados = new ArrayList();
        String [] Colunas = new String[]{"ID","Nome","Entrada Manha Padrão","Saida Manhã Padrão","Entrada Tarde Padrão","Saida Tarde Padrão"};   
        conecta.executaSQL(SQL);
        try {
            conecta.rs.first();
            do{
                dados.add(new Object[]{conecta.rs.getInt("id"),conecta.rs.getString("nomefuncionarios"),conecta.rs.getString("entradamanhapadrao"),conecta.rs.getString("saidamanhapadrao"),conecta.rs.getString("entradatardepadrao"),conecta.rs.getString("saidatardepadrao")});
            }while(conecta.rs.next());
     } catch (SQLException ex) {
          // JOptionPane.showMessageDialog(null, "Erro ao preencher o ArrayList!");
        }
        
        ModeloTabela modelo = new ModeloTabela(dados, Colunas);
        Tabelafuncionarios.setModel(modelo);
        Tabelafuncionarios.getColumnModel().getColumn(0).setPreferredWidth(50);
        Tabelafuncionarios.getColumnModel().getColumn(0).setResizable(false);
        Tabelafuncionarios.getColumnModel().getColumn(1).setPreferredWidth(200);
        Tabelafuncionarios.getColumnModel().getColumn(1).setResizable(false);
        Tabelafuncionarios.getColumnModel().getColumn(2).setPreferredWidth(180);
        Tabelafuncionarios.getColumnModel().getColumn(2).setResizable(false);
        Tabelafuncionarios.getColumnModel().getColumn(3).setPreferredWidth(180);
        Tabelafuncionarios.getColumnModel().getColumn(3).setResizable(false);
        Tabelafuncionarios.getColumnModel().getColumn(4).setPreferredWidth(180);
        Tabelafuncionarios.getColumnModel().getColumn(4).setResizable(false);
        Tabelafuncionarios.getColumnModel().getColumn(5).setPreferredWidth(180);
        Tabelafuncionarios.getColumnModel().getColumn(5).setResizable(false);
        Tabelafuncionarios.setAutoResizeMode(Tabelafuncionarios.AUTO_RESIZE_OFF);
        Tabelafuncionarios.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    
    }
     /* @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Cadastrofuncionarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Cadastrofuncionarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Cadastrofuncionarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Cadastrofuncionarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Cadastrofuncionarios().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable Tabelafuncionarios;
    private javax.swing.JButton btnatualizar;
    public javax.swing.JButton btneditar;
    private javax.swing.JButton btnexcluir;
    private javax.swing.JButton btnlimpar;
    public javax.swing.JButton btnsalvar;
    public javax.swing.JTextField campoentradamanha;
    public javax.swing.JTextField campoentradatarde;
    public javax.swing.JTextField campoexclusao;
    public javax.swing.JTextField camponome;
    public javax.swing.JTextField camposaidamanha;
    public javax.swing.JTextField camposaidatarde;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    // End of variables declaration//GEN-END:variables
}
