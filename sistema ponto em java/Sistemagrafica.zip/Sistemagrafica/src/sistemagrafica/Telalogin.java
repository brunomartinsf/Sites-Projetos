package sistemagrafica;
import com.sun.glass.events.KeyEvent;
import java.sql.*;
import utilitarios.ConectaBanco;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class Telalogin extends javax.swing.JFrame {
   private final ConectaBanco conecta;
    Connection conexao ;
    PreparedStatement pst = null;
    ResultSet rs = null;
   
    public void logar(){
        String sql= "select * from login where usuario=? and senha=?";
        try{
            pst = conexao.prepareStatement(sql);
            pst.setString(1,campousuario.getText());
            pst.setString(2, camposenha.getText());
            rs = pst.executeQuery();            
            if(rs.next()){
                Inicio inicio=new Inicio();
                inicio .setVisible(true);
            }else{
                JOptionPane.showMessageDialog(null, "Usuario ou senha invalido");
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
     
    public Telalogin() {
        initComponents();
       conecta = new ConectaBanco();
    }
 @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        campousuario = new javax.swing.JTextField();
        btnentrar = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        camposenha = new javax.swing.JPasswordField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Login");
        setResizable(false);

        jLabel1.setText("Usuario:");

        jLabel2.setText("Senha:");

        btnentrar.setText("Entrar");
        btnentrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnentrarActionPerformed(evt);
            }
        });
        btnentrar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                btnentrarKeyPressed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel4.setText("Gráfica Fama's");

        camposenha.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                camposenhaKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(76, 76, 76)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(campousuario, javax.swing.GroupLayout.DEFAULT_SIZE, 156, Short.MAX_VALUE)
                    .addComponent(camposenha))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(157, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(btnentrar)
                        .addGap(160, 160, 160))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addGap(144, 144, 144))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 33, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(campousuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(camposenha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(btnentrar)
                .addGap(13, 13, 13))
        );

        setSize(new java.awt.Dimension(408, 200));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnentrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnentrarActionPerformed
        // TODO add your handling code here:
        try{
            conecta.conexao();
            conecta.stm=conecta.conn.createStatement();
            String SQL;
            SQL = "select *from login";
            conecta.rs=conecta.stm.executeQuery(SQL);
            conecta.rs.first();
            
            if(campousuario.getText().equals(conecta.rs.getString("usuario"))&& camposenha.getText().equals(conecta.rs.getString("senha"))){
                JOptionPane.showMessageDialog(null, "Usuario conectado");
                Inicio inicio = new Inicio();
                inicio.setVisible(true);
                dispose();
                
            }else{
                JOptionPane.showMessageDialog(null, "Usuario Invalido");
                campousuario.setText("");
                camposenha.setText("");
            }
            
        }catch(SQLException ex){
            Logger.getLogger(Telalogin.class.getName()).log(Level.SEVERE,null,ex);
        }  
    }//GEN-LAST:event_btnentrarActionPerformed

    private void btnentrarKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_btnentrarKeyPressed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_btnentrarKeyPressed

    private void camposenhaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_camposenhaKeyPressed
        // TODO add your handling code here:
        if(evt.getKeyCode()==KeyEvent.VK_ENTER){
        
        try{
            conecta.conexao();
            conecta.stm=conecta.conn.createStatement();
            String SQL;
            SQL = "select *from login";
            conecta.rs=conecta.stm.executeQuery(SQL);
            conecta.rs.first();
            
            if(campousuario.getText().equals(conecta.rs.getString("usuario"))&& camposenha.getText().equals(conecta.rs.getString("senha"))){
                JOptionPane.showMessageDialog(null, "Usuario conectado");
                Inicio inicio = new Inicio();
                inicio.setVisible(true);
                dispose();
                
            }else{
                JOptionPane.showMessageDialog(null, "Usuario Invalido");
                campousuario.setText("");
                camposenha.setText("");
            }
            
        }catch(SQLException ex){
            Logger.getLogger(Telalogin.class.getName()).log(Level.SEVERE,null,ex);
        }  
        }
    }//GEN-LAST:event_camposenhaKeyPressed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Telalogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Telalogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Telalogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Telalogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Telalogin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnentrar;
    private javax.swing.JPasswordField camposenha;
    private javax.swing.JTextField campousuario;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    // End of variables declaration//GEN-END:variables
}
