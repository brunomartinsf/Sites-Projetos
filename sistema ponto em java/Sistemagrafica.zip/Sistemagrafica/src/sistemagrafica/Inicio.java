package sistemagrafica;

//import modelo.ConectaBanco;
import com.itextpdf.text.BaseColor;

import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.PageSize;
//import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import java.awt.Color;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import utilitarios.ConectaBanco;


public class Inicio extends javax.swing.JFrame {
    ConectaBanco conexao=new ConectaBanco();
    static Statement statement;
   static Connection connection;
    static ConectaBanco con_entradasaida;

    public Inicio() {
        initComponents();
        this.setLocationRelativeTo(null);
        conexao.conexao();
        getContentPane().setBackground(Color.DARK_GRAY);
        this.setExtendedState(MAXIMIZED_BOTH);
         
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel4 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        jMenuItem3 = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        jMenuItem2 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Inicio");
        setBackground(new java.awt.Color(102, 102, 102));

        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("© Gráfica Fama´s");
        jLabel1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Desenvolvido por Bruno Martins - (85) 98532.8576");
        jLabel2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        jLabel4.setIcon(new javax.swing.ImageIcon("C:\\Users\\PrJr\\Pictures\\photo.jpg")); // NOI18N

        jMenu1.setText("Funcionários");

        jMenuItem1.setText("Cadastrar Funcionarios");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem1);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Entrada/Saida");

        jMenuItem3.setText("Cadastrar Entrada/Saida");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItem3);

        jMenuBar1.add(jMenu2);

        jMenu3.setText("Gerar Relatório");

        jMenuItem2.setText("Entrada/Saida");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem2);

        jMenuBar1.add(jMenu3);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jSeparator1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(617, 617, 617)
                        .addComponent(jLabel4)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(549, 549, 549)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(64, 64, 64)
                        .addComponent(jLabel1)))
                .addContainerGap(554, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(225, 225, 225)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 169, Short.MAX_VALUE)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1)
                .addGap(3, 3, 3)
                .addComponent(jLabel2)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        // TODO add your handling code here:
        Cadastrofuncionarios cf = new Cadastrofuncionarios();
        cf.setVisible(true);
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
        // TODO add your handling code here:
        
        Cadastroentradasaida ces= new Cadastroentradasaida();
        ces.setVisible(true);
    }//GEN-LAST:event_jMenuItem3ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        try {
            gerarpdf();
        } catch (IOException ex) {
            Logger.getLogger(Inicio.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Inicio.class.getName()).log(Level.SEVERE, null, ex);
        }                  
    }//GEN-LAST:event_jMenuItem2ActionPerformed
    public void gerarpdf() throws IOException, SQLException{
        Document document= null ;
           OutputStream outPutStream=null;
           try{
               
               document = new Document (PageSize.A4.rotate(),-103,-103,0,0);
               outPutStream = new FileOutputStream("C:/Users/PrJr/Documents/Relatorio.pdf");          
               try{                                 
                   PdfWriter.getInstance(document, outPutStream);
                    document.open();          
                     PdfPTable tabela = new PdfPTable(11); 
                    
                     PdfPCell cabecalho = new PdfPCell(new Paragraph("GRÁFICA FAMA´S \n Relatório Entrada/Saída"));           
                     cabecalho.setHorizontalAlignment(Element.ALIGN_CENTER);
                     cabecalho.setBorder(PdfPCell.NO_BORDER);
                     cabecalho.setBackgroundColor(new BaseColor(100,150,200));
                     cabecalho.setColspan(11);
                     tabela.addCell(cabecalho);
                     tabela.addCell("ID");
                     tabela.addCell("NOME");
                     tabela.addCell("DATA");
                     tabela.addCell("MANHÃ ENTRADA");
                     tabela.addCell("OBS.MANHÃ");
                     tabela.addCell("MANHÃ SAÍDA");
                     tabela.addCell("OBS.MANHÃ");
                     tabela.addCell("TARDE ENTRADA");
                     tabela.addCell("OBS.TARDE");
                     tabela.addCell("TARDE SAÍDA");
                     tabela.addCell("OBS.TARDE");
                     con_entradasaida = new ConectaBanco();
                    con_entradasaida.conexao();
                     statement = con_entradasaida.conn.createStatement();    
                    con_entradasaida.executaSQL("select * from cadentradasaida1");                    
                    while(con_entradasaida.rs.next()){
                        tabela.addCell(con_entradasaida.rs.getString("ID"));
                        tabela.addCell(con_entradasaida.rs.getString("Nome"));
                        tabela.addCell(con_entradasaida.rs.getString("Data"));
                        tabela.addCell(con_entradasaida.rs.getString("HoraManhãEntrada"));
                        tabela.addCell(con_entradasaida.rs.getString("Obs_ManhãChegada"));
                        tabela.addCell(con_entradasaida.rs.getString("HoraManhãSaida"));
                        tabela.addCell(con_entradasaida.rs.getString("Obs_ManhãSaida"));
                        tabela.addCell(con_entradasaida.rs.getString("HoraTardeEntrada"));
                        tabela.addCell(con_entradasaida.rs.getString("Obs_TardeChegada"));
                        tabela.addCell(con_entradasaida.rs.getString("HoraTardeSaida"));
                        tabela.addCell(con_entradasaida.rs.getString("Obs_TardeSaida"));
                    }   
                    document.add(tabela);                   
                     JOptionPane.showMessageDialog(null,"Relatório gerado com sucesso!");                 
        } catch (DocumentException ex) {
            JOptionPane.showMessageDialog(null,"Ero ao gerar relatório: "+ex);
        }
           }     
       finally{
            if(document != null){
                document.close();
            }
            if (outPutStream!= null){
                outPutStream.close();
            }
        }       
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Inicio().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JSeparator jSeparator1;
    // End of variables declaration//GEN-END:variables
}
